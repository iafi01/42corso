#include <stdio.h>

void ft_print_comb2(void);

int main(void)
{
	printf("---Expected-output---\n");
	printf("00 01, 00 02, ..., 00 99, 01 02, ..., 97 99, 98 99\n");
	printf("----Actual---output---\n");
	ft_print_comb2();
}
