#include <stdio.h>

void ft_print_numbers(void);

int main(void)
{
	printf("---Expected-output---\n");
	printf("0123456789\n");
	printf("----Actual---output---\n");

	ft_print_numbers();
}
