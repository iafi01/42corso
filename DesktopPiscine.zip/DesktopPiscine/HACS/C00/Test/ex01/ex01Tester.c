#include <stdio.h>

void ft_print_alphabet(void);

int main(void)
{
	printf("---Expected-output---\n");
	printf("abcdefghijklmnopqrstuvwxyz\n");
	printf("----Actual---output---\n");

	ft_print_alphabet();
}
