#include <stdio.h>

void ft_print_reverse_alphabet(void);

int main(void)
{
	printf("---Expected-output---\n");
	printf("zyxwvutsrqponmlkjihgfedcba\n");
	printf("----Actual---output---\n");

	ft_print_reverse_alphabet();
}
