          %%%%%%%%%%%%%           %%%%%%%%%%%          
      %%%%%           %%%%    %%%%          %%%%%      
     %%%%%               %%%%%%%              %%%%%    
    %%% %%%%%%%%%          %%%             %%%%% %%%   
    %%     %%%%%%           %           %%%%%     %%%  
    %%        %%%%%%%               %%%%%%         %%  
    %%           %%%%%%%        %%%%%%%%          %%%  
     %%             %%%%%%%   %%%%%%             %%%   
      %%                %%%%%%%%%               %%     
       %%%             %%%%%%%%%%             %%%      
         %%%        %%%%%%    %%%%%%        %%%        
           %%%   %%%%%%         %%%%%%%   %%%          
             %%%%%%%                 %%%%%%            
 Heartless      %%%                  %%%               
 Automated        %%%              %%%                 
 Correction         %%%          %%%                   
 Script V1.3          %%        %%                     
                       %%      %%                      
 Made by:              %%      %%                      
 Fabio Facilla         %%       %%                     
                   %%%%%         %%%%%                 
             %%%%%%%                %%%%%%%%           
                %%%%%%%%%      %%%%%%%%%%              
                       %%%    %%%                      
 Please report any bugs %%%  %%%                       
 you find on Slack        %%%%%                        
                            %                          


     --- INSTRUCTIONS ---

1 : cd into the HACS directory from your terminal

2 : type: ./HACS.sh followed by the module you are evaluating, followed by the link of the repository,

Example: ./HACS.sh C02 git@vogsphere.42roma.it:vogsphere/intra-uuid-5ef209f9-4288-4d28-8e43-1e2f95817edf-3394683

Note, once you launch this command, HACS will try to update itself to its latest version from GitHub, undoing any modifications you may have done to the HACS files.

3 : follow the on-screen instructions

4 : Thanks for using HACS

Note, if you stop the script prematurely, it will not remove any files downloaded from the student's repository during the execution


If you find any bugs or errors in the code, please contact me on Slack(Fabio Facilla),
or send me an email at fabio.facilla@gmail.com

