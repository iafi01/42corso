char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	
}
