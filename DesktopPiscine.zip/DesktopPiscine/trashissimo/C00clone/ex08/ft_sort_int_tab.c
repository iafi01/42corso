/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/01 19:19:37 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/09 13:30:32 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int i;
	int sos;
	int j;

	i = 0;
	while (i < size - 1)
	{
		j = 0;
		while (j < size - 1)
		{
			if (tab[i] > tab[i + 1])
			{
				sos = tab[j];
				tab[j] = tab[i + 1];
				tab[i + 1] = sos;
			}
			j++;
		}
		i++;
	}
}
