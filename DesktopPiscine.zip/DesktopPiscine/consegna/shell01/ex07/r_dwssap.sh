#!/bin/sh
cat /etc/passwd | grep "^[^#;]" | awk 'NR%2==0'
