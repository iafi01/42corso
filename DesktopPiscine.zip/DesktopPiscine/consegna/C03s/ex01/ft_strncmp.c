/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/05 09:58:57 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/06 17:16:42 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	int				res;

	res = 0;
	i = 0;
	while (s1[i] || s2[i])
	{
		if (i < n)
		{
			if (s1[i] != s2[i])
			{
				res = s1[i] - s2[i];
				return (res);
			}
		}
		i++;
	}
	return (0);
}
