/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/01 19:19:37 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/02 16:28:52 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int i;
	int sos;
	int flag;

	i = 0;
	while (i < size)
	{
		flag = 0;
		if (tab[i] > tab[i + 1])
		{
			flag = 1;
			sos = tab[i];
			tab[i] = tab[i + 1];
			tab[i + 1] = sos
		}
		if (flag = 0)
			break;
		i++;
	}
}
