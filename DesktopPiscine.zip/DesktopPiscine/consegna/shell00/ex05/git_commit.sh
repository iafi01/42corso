#!/bin/sh
git log -5 --format=%H
