/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ciao.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/27 12:47:15 by liafigli          #+#    #+#             */
/*   Updated: 2020/11/30 17:48:26 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	scrivi(char a, char b, char c)
{
	write(1, &a, 1);
	write(1, &b, 1);
	write(1, &c, 1);
}

void	scrivi_due(char c, char d)
{
	write(1, &c, 1);
	write(1, &d, 1);
}

void	ft_print_comb(void)
{
	char first;
	char second;
	char third;

	first = '0';
	while (first <= '7')
	{
		second = first + 1;
		while (second <= '8')
		{
			third = second + 1;
			while (third <= '9')
			{
				scrivi(first, second, third);
				if (first != '7' || second != '8' || third != '9')
				{
					scrivi_due(',', ' ');
				}
				third++;
			}
			second++;
		}
		first++;
	}
}
