/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/03 17:20:06 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/06 10:25:45 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[0] >= 'a' && str[0] <= 'z')
			str[i] -= 32;
		if (str[i] >= ' ' && str[i + 1] >= 'a' && str[i + 1] <= 'z')
			if (str[i] < 'A' || str[i] > 'Z')
				if (str[i] < '0' || str[i] > '9')
					str[i + 1] -= 32;
		if ((str[i] >= 'a' && str[i] <= 'z')
		|| (str[i] >= 'A' && str[i] <= 'Z'))
			if (str[i + 1] >= 'A' && str[i + 1] <= 'Z')
				str[i + 1] += 32;
		i++;
	}
	return (str);
}
