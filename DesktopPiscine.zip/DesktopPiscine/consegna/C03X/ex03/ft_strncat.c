/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/06 14:40:11 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/06 17:27:03 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int i;
	unsigned int t;

	i = 0;
	while (dest[i])
	{
		i++;
	}
	t = 0;
	while (src[t] && i < nb)
	{
		dest[i] = src[t];
		i++;
		t++;
	}
	dest[i] = 0;
	return (dest);
}
