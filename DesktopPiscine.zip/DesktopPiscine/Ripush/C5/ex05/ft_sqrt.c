int ft_sqrt(int nb)
{
	
}
