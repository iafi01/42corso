int ft_fibonacci(int index)
{	int a;
	int b;
	int res;
	if (index < 0)
		return (-1);
	res = 
}
