/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 19:21:59 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/09 15:03:12 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		spazi(char *str, int i)
{
	while (str[i])
	{
		if (str[i] == '\t' || str[i] == '\n' || str[i] == '\v' ||
			str[i] == '\f' || str[i] == '\r' ||
			str[i] == ' ')
			i++;
		else
			break ;
    }
}

int		segni(char *str, int i, int meno)
{
	while (str[i])
	{
		if (str[i] == '-' || str[i] == '+')
			if (str[i] == '-')
			{
				meno++;
				i++;
			}
		else
			break ;
	}
}

int		ft_atoi(char *str)
{
	int i;
	int meno;
	int sum;

	meno = 0;
	i = 0;
	sum = 0;
	spazi(str, i);
	segni(str, i, meno);
	while (str[i])
	{
		if (str[i] >= '0' && str[i] <= '9')
		{
			sum *= 10;
			sum += str[i] - '0';
			i++;
		}
		else
			break ;
	}
	if (meno % 2 == 0)
		return (sum);
	else
		return (sum * -1);
}
