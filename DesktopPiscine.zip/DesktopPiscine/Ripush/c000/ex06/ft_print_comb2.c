/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/27 14:47:05 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/09 12:59:53 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	scrivi(char c)
{
	write(1, &c, 1);
}

void	print(int a, int b)
{
	scrivi('0' + a / 10);
	scrivi('0' + a % 10);
	scrivi(' ');
	scrivi('0' + b / 10);
	scrivi('0' + b % 10);
	if (a != 98 || b != 99)
	{
		scrivi(',');
		scrivi(' ');
	}
}

void	ft_print_comb2(void)
{
	int a;
	int b;

	a = 0;
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			print(a, b);
			b++;
		}
		a++;
	}
}
