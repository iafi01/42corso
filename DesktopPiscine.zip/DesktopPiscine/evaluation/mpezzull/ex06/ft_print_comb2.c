/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpezzull <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/26 09:08:50 by mpezzull          #+#    #+#             */
/*   Updated: 2020/11/28 16:52:25 by mpezzull         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_comb2(void)
{
	int		comb[2];
	char	result_comb[2][2];

	comb[0] = 0;
	comb[1] = 1;
	while (comb[0] < comb[1] & comb[0] <= 98)
	{
		while (comb[1] <= 99)
		{
			result_comb[0][0] = comb[0] / 10 + 48;
			result_comb[0][1] = comb[0] % 10 + 48;
			result_comb[1][0] = comb[1] / 10 + 48;
			result_comb[1][1] = comb[1] % 10 + 48;
			write(1, &result_comb[0], 2);
			write(1, " ", 1);
			write(1, &result_comb[1], 2);
			if (comb[0] != 98 | comb[1] != 99)
			{
				write(1, ", ", 2);
			}
			comb[1]++;
		}
		comb[0]++;
		comb[1] = comb[0] + 1;
	}
}
