/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpezzull <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/26 15:11:41 by mpezzull          #+#    #+#             */
/*   Updated: 2020/11/27 11:44:08 by mpezzull         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print(int comb[], int n)
{
	int		i;
	char	digit;

	i = 0;
	while (i < n)
	{
		digit = comb[i++] + 48;
		write(1, &digit, 1);
	}
	if (comb[0] != 10 - n)
	{
		write(1, ", ", 2);
	}
}

void	ft_while_next(int comb[], int pos, int n)
{
	int count;

	if (pos == 0)
	{
		count = 0;
	}
	else if (pos != n)
	{
		count = comb[pos - 1] + 1;
	}
	else
	{
		count = comb[pos - 1] + 1;
		ft_print(comb, n);
		return ;
	}
	while (count <= 9)
	{
		comb[pos] = count;
		ft_while_next(comb, pos + 1, n);
		count++;
	}
}

void	ft_print_combn(int n)
{
	int comb[n];

	ft_while_next(comb, 0, n);
}
