/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mpezzull <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/26 11:57:45 by mpezzull          #+#    #+#             */
/*   Updated: 2020/11/28 16:57:11 by mpezzull         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_exponential_ten(short int num)
{
	int result;

	result = 1;
	while (num-- > 0)
	{
		result = result * 10;
	}
	return (result);
}

int		ft_write_sign(int nb)
{
	if (nb < 0)
	{
		write(1, "-", 1);
		nb = nb * (-1);
	}
	return (nb);
}

void	ft_putnbr(int nb)
{
	char	digit;
	int		exp10;
	int		go;

	exp10 = 9;
	go = 0;
	nb = ft_write_sign(nb);
	while (exp10 >= 0)
	{
		digit = (nb / ft_exponential_ten(exp10)) % 10 + 48;
		if (digit != 48 & go != 1)
		{
			go = 1;
		}
		if (go > 0)
		{
			write(1, &digit, 1);
		}
		exp10--;
	}
	if (nb == 0)
	{
		write(1, "0", 1);
	}
}
