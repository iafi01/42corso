ifconfig | grep 'ether' | grep -o '..:..:..:..:..:..'
