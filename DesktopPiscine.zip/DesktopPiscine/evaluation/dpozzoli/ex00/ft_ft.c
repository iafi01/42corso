/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dpozzoli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/28 12:03:25 by dpozzoli          #+#    #+#             */
/*   Updated: 2020/11/30 16:05:20 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ft(int *nbr)
{
	*nbr = 42;
}


int main()
{
	int *punt;
	int a;

	a = 5;
	printf("valore iniziale: %d \n", a);

	punt = &a;
	ft_ft(punt);
	printf("Valore finale: %d", a);
	return 0;
}
