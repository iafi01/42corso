/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dpascale <dpascale@student.42roma.it>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/25 13:37:40 by dpascale          #+#    #+#             */
/*   Updated: 2020/11/25 15:49:11 by dpascale         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print(char a, char b, char c)
{
	write(1, &a, 1);
	write(1, &b, 1);
	write(1, &c, 1);
}

void	ft_print_signs(void)
{
	char	comma;
	char	space;

	comma = ',';
	space = ' ';
	write(1, &comma, 1);
	write(1, &space, 1);
}

void	ft_print_comb(void)
{
	int	index1;
	int	index2;
	int	index3;

	index1 = 0;
	while (index1 < 10)
	{
		index2 = index1 + 1;
		while (index2 < 10)
		{
			index3 = index2 + 1;
			while (index3 < 10)
			{
				ft_print(index1 + 48, index2 + 48, index3 + 48);
				index3++;
				if (index1 == 7 && index2 == 8 & index3 == 10)
					continue;
				ft_print_signs();
			}
			index2++;
		}
		index1++;
	}
}
