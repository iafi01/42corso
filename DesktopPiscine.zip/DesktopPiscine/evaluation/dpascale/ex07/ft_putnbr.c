/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dpascale <dpascale@student.42roma.it>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/25 18:03:51 by dpascale          #+#    #+#             */
/*   Updated: 2020/11/25 18:11:54 by dpascale         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print(char c)
{
	c += 48;
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	char	minus;
	int		div;
	int		flag;

	minus = '-';
	div = 1000000000;
	flag = 0;
	if (nb < 0)
	{
		write(1, &minus, 1);
		nb *= -1;
	}
	while (div != 0)
	{
		if (nb / div > 0)
			flag = 1;
		if (nb / div >= 0 && flag == 1)
		{
			ft_print(nb / div);
			nb -= (nb / div) * div;
		}
		div /= 10;
	}
}
