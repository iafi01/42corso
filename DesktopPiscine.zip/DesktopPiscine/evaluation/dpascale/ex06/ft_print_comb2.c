/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dpascale <dpascale@student.42roma.it>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/25 16:28:34 by dpascale          #+#    #+#             */
/*   Updated: 2020/11/25 17:36:20 by dpascale         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print(char a, char b, char c, char d)
{
	char	space;

	a += 47;
	b += 47;
	c += 47;
	d += 47;
	space = ' ';
	write(1, &a, 1);
	write(1, &b, 1);
	write(1, &space, 1);
	write(1, &c, 1);
	write(1, &d, 1);
	if (!(a == '9' && b == '8' && c == '9' && d == '9'))
	{
		ft_print_signs();
	}
}

void	ft_print_signs(void)
{
	char	space;
	char	comma;

	space = ' ';
	comma = ',';
	write(1, &space, 1);
	write(1, &space, 1);
}

void	ft_print_comb2(void)
{
	int	index1;
	int	index2;
	int	index3;
	int	index4;

	index1 = 0;
	while (index1++ < 10)
	{
		index2 = 0;
		while (index2++ < 10)
		{
			index3 = 0;
			while (index3++ < 10)
			{
				index4 = 0;
				while (index4++ < 10)
				{
					if ((index1 * 10 + index2) < (index3 * 10 + index4))
						ft_print(index1, index2, index3, index4);
				}
			}
		}
	}
}
