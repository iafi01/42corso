#!/bin/sh
git ls-files -o --ignored --exclude-standard
