/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jnataliz <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/26 19:05:20 by jnataliz          #+#    #+#             */
/*   Updated: 2020/11/26 19:07:57 by jnataliz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int number)
{
	char	negative_number;
	char	positive_number;

	negative_number = 'N';
	positive_number = 'P';
	if (number < 0)
	{
		write(1, &negative_number, 1);
	}
	else
	{
		write(1, &positive_number, 1);
	}
}
