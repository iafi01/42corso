/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jnataliz <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/29 13:54:03 by jnataliz          #+#    #+#             */
/*   Updated: 2020/11/30 09:51:31 by jnataliz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_int(int a, int b)
{
	char d_a;
	char u_a;
	char d_b;
	char u_b;

	d_a = (a - (a % 10)) / 10 + '0';
	d_b = (b - (b % 10)) / 10 + '0';
	u_a = (a % 10 + '0');
	u_b = (b % 10 + '0');
	write(1, &d_a, 1);
	write(1, &u_a, 1);
	write(1, &" ", 1);
	write(1, &d_b, 1);
	write(1, &u_b, 1);
	write(1, &", ", 2);
}

void	ft_print_comb2(void)
{
	int a;
	int b;

	a = 0;
	b = 1;
	while (a <= 97)
	{
		while (b <= 99)
		{
			print_int(a, b);
			b++;
		}
		a++;
		b = a + 1;
	}
	write(1, &"98 99", 5);
}
