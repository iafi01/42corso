#!/bin/bash
git log --format=format:%H|head -n 5
