git-ls file --others -i --exclude-standard
