/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/10 11:58:18 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/10 11:59:09 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_is_prime(int nb)
{
	int i;

	i = 0;
	if (nb <= 1)
		return (1);
	i = 2;
	while (i < nb / 2)
	{
		if (nb % i == 0)
			return (0);
		i++;
	}
	return (1);
}

int		ft_find_next_prime(int nb)
{
	int i;

	i = 0;
	if (nb == 0)
		return (0);
	if (nb == 1)
		return (1);
	i = nb;
	while (i >= nb)
	{
		if (ft_is_prime(i) == 1)
			return (i);
		i++;
	}
	return (1);
}
