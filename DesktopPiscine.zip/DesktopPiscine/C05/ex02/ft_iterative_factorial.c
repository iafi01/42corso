/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: liafigli <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/10 12:01:32 by liafigli          #+#    #+#             */
/*   Updated: 2020/12/10 12:01:55 by liafigli         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_iterative_power(int nb, int power)
{
	int i;
	int res;

	i = 0;
	res = 1;
	if (power == 0)
		return (1);
	else if (nb == 0)
		return (0);
	else if (nb < 0 || power < 0)
		return (0);
	else
	{
		while (i < power)
		{
			res *= nb;
			i++;
		}
	}
	return (res);
}
